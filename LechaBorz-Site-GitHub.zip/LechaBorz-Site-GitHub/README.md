# Lecha BORZ Token Website

This is the official website of the Lecha BORZ token, deployed on Ethereum.
Built for investors, community, and transparency.

- Live DEXTools chart
- Buy on Uniswap button
- Whitepaper download
- Socials: Telegram, Twitter

## Visit the Site
👉 https://salakh296.github.io/LechaBorz-Site/